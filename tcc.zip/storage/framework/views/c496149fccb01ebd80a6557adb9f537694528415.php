

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', [
        'title' => __(''),
        'description' => __(''),
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--4">
        <div class="row">
            
            <div class="col-xl-12 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Cadastro do area')); ?> <?php echo e($area->nome); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('area.update',$area->id)); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Dados do area')); ?></h6>
                            
                            <?php if(session('status')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('status')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col">
                                    <div class="form-group<?php echo e($errors->has('qtde_embalagem') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-qtde_embalagem"><?php echo e(__('Quantidade na Embalagem')); ?></label>
                                        <input type="number"  min="1" name="qtde_embalagem" id="input-qtde_embalagem" class="form-control form-control-alternative<?php echo e($errors->has('qtde_embalagem') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Nomea')); ?>" value="<?php echo e(old('qtde_embalagem', $area->nome)); ?>" required>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group<?php echo e($errors->has('observacao') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-observacao"><?php echo e(__('Descrição')); ?></label>
                                        <textarea id="story" name="descricao"rows="2" cols="33" class="form-control form-control-alternative<?php echo e($errors->has('observacao') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Descrição')); ?>" value="<?php echo e(old('observacao', $area->descricao)); ?>"></textarea>
                                    </div>
                                </div>
                            </div>
                    
                            
                            <div class="text-left">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>
                                </div>
                            </div>
                        </form>
                        <hr class="my-4" />
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Forncedor')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistema-auxilio-tema-de-tcc\resources\views/area/edit.blade.php ENDPATH**/ ?>