

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', [
        'title' => __(''),
        'description' => __(''),
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--4">
        <div class="row">
            
            <div class="col-xl-12 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="col-12 mb-0"><?php echo e(__('Cadastro Professor')); ?></h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('professor.store')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>

                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Dados do professor')); ?></h6>
                            
                            <?php if(session('status')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('status')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <div class="row">
                                
                                <div class="col">
                                    <div class="form-group<?php echo e($errors->has('qtde_embalagem') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-qtde_embalagem"><?php echo e(__('Nome')); ?></label>
                                        <input type="text"  min="1" name="nome" id="input-qtde_embalagem" class="form-control form-control-alternative<?php echo e($errors->has('qtde_embalagem') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Nome')); ?>" value="<?php echo e(old('qtde_embalagem')); ?>" required>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group<?php echo e($errors->has('qtde_embalagem') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-qtde_embalagem"><?php echo e(__('Matrícula')); ?></label>
                                        <input type="text"  min="1" name="matricula" id="input-qtde_embalagem" class="form-control form-control-alternative<?php echo e($errors->has('qtde_embalagem') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Matrícula')); ?>" value="<?php echo e(old('qtde_embalagem')); ?>" required>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group<?php echo e($errors->has('categoria') ? ' has-danger' : ''); ?>">
                                        <label class="form-control-label" for="input-categoria"><?php echo e(__('Áreas')); ?></label>
                                        <select class="form-control<?php echo e($errors->has('categoria') ? ' is-invalid' : ''); ?>" name="fk_areas_id"    required="true" aria-required="true">
                                            <option value=""><?php echo e('Selecione a Área'); ?></option>
                                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>">
                                                <?php echo e($value); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                                    <div class="text-left">
                                        <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <hr class="my-4" />
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Professor')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistema-auxilio-tema-de-tcc\resources\views/professor/create.blade.php ENDPATH**/ ?>