<!-- need to remove -->
<li class="nav-item">
    <a href="../widgets.html" class="nav-link">
        <i class="nav-icon fas fa-th"></i>
        <p>Widgets</p>
    </a>
</li>

<li class="nav-item">
    <a href="gallery.html" class="nav-link">
        <i class="nav-icon far fa-image"></i>
        <p>Gallery</p>
    </a>
</li>
